## MAGICRAFT CHANGE LOG & HISTORY

Magicraft is a WordPress theme perfect fit for the Minecraft servers with a online status. Theme has design specially made for Minecraft and many options to customize final look of the website. Magicraft is a fluid and fully responsive theme, which adapting display to all devices (smartphones, tablets, laptops, desktops …). The theme also serves as a great blogging tool. Source code of theme is highly semantic and well structured, which is also very good for all search engines – SEO optimalized.

Check our blog news and free skins http://magicraft.creepy.cz/blog/ .

http://magicraft.creepy.cz/

Author: Creepy Studio [David Dvořáček, Zdeněk Studený]

*******************************************************************

**v1.00**
- Proud to present great solution for Minecraft servers.
- Online status for servers
- Responsive for multidevices functionality
- 2 skins in base (Dirt & Nether)
- Fully customizable
- Slider

**v1.1**
- New Server status - using server ping and GS4 status listener, script is powered by Minecraft Query from xPaw
- Added function to increase space before and after logo 
- With new skin there is also possibility to change colors of online status and footer background image
- Added tags to posts
- Fixed bad formating for some widgets
- Fixed bug, where some headings didn't change font

**v1.1.01
- Bug fixes - Online players weren't refreshing for non-logged visitors

**v1.20**

- After several requests we add new page template for FORUMS (100% width)
- Online status updated and redesigned, now also support other ports than 25565. 
- Added function, where it's possible to add manually server version 
- Added visual support for plugins
- Server status plugin - https://wordpress.org/plugins/minecraft-server-status-checker/
- User login widget- https://wordpress.org/plugins/sidebar-login/
- User login widget with AJAX (no page reload) - https://wordpress.org/plugins/login-with-ajax/
