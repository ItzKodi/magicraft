# Magicraft
__A premium Wordpress Theme for Minecraft__

Magicraft is a WordPress theme perfect fit for the Minecraft servers with a online status. Theme has design specially made for Minecraft and many options to customize final look of the website. Magicraft is a fluid and fully responsive theme, which adapting display to all devices (smartphones, tablets, laptops, desktops …). The theme also serves as a great blogging tool. Source code of theme is highly semantic and well structured, which is also very good for all search engines – SEO optimalized.

Designed by **Creepy Studio**: http://magicraft.creepy.cz/

Submit Bugs & or Fixes:
http://magicraft.creepy.cz/forum/

Thank you! 


## Regular license

#What is Regular license?

The Regular License allows use of the item in one single end product which end users are not charged to access or use. Distribution of source files is not permitted.


#Things you can't do with the item

1.You can’t Sell the End Product, except to one client. (If you or your client want to Sell the End Product, you will need the Extended License.)
2.You can’t re-distribute the Item as stock, in a tool or template, or with source files. You can’t do this with an Item either on its own or bundled with other items, and even if you modify the Item. You can’t re-distribute or make available the Item as-is or with superficial modifications. These things are not allowed even if the re-distribution is for Free.

For example: You can’t purchase an template, add more functionality or change layout and sell or give it to more than one client. You can’t license an item and then make it available as-is on your website for your users to download.

3.Although you can modify the Item and therefore delete unwanted components before creating your single End Product, you can’t extract and use a single component of an Item on a stand-alone basis.
For example: You license a website theme containing icons. You can delete unwanted icons from the theme. But you can't extract an icon to use outside of the theme.

4.You must not permit an end user of the End Product to extract the Item and use it separately from the End Product.
5.You can’t use an Item in a logo, trademark, or service mark.
